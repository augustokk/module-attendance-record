# Augusto Kuusberg Elias
# R00181405
# SOFT_6017 PROJECT
# 2020


def heading(option):
    """ This function allow us to create a different options of heading, changing the parameter option"""
    header = f'Module Record System {option}'
    print(header)
    print(len(header) * '-')


def positive_number(prompt):
    """This function enable us to verify if the input is an integer and positive """
    while True:
        try:
            number = int(input(prompt))
            if number > 0:
                break
            else:
                print("Non-negative numbers please...")
        except ValueError:
            print("Must be numeric...")
    return number


def read_string_with_letters_only_name(prompt):
    """ this is a function to check if the user is writing a string and if they are just letters """
    while True:
        phrase = input(prompt)
        copy = phrase.replace(" ", "")  # remove all spaces
        if len(phrase) > 0 and copy.isalpha():  # check if it has at least one character and if they are just alphabets
            return phrase
        else:
            print('Please type letters only')


def read_string_password(prompt):
    """this is a function to check if the user is writing a string, in this case can use letters, numbers and simbol"""
    while True:
        phrase = input(prompt)
        copy = phrase.replace(" ", "")  # remove all spaces
        if len(copy) > 0:  # check if it has at least one character
            return phrase
        else:
            print('Please try again')


def login_data():
    """ This function is used to get input from user of name and password"""
    name = read_string_with_letters_only_name("Name: ")
    password = read_string_password('Password: ')
    return name, password


def read_data_login(name_file):
    """ This function create two lists to store name and password from a specific file """
    name_list = []
    password_list = []
    connection = open(name_file)
    while True:
        line = connection.readline().rstrip()
        if line == "":
            break
        name_list.append(line)
        line = connection.readline().rstrip()
        password_list.append(line)
    return name_list, password_list


def login_validation(name, password, name_file, password_file):
    """This function will compare if the name and password given by user are the same
     as we have in the file (login_data.txt)"""
    # if statement to check if name and password given by user are in the list
    start_program = ''
    if name not in name_file or password not in password_file:
        heading(f'- Login Failed')
        start_program = 'no'

    # elif statement created to check if the password  not belongs to the user
    elif name != name_file[password_file.index(password)] and password != password_file[name_file.index(name)]:
        heading(f'- Login Failed')
        start_program = 'no'

    # elif statement confirming that user has that password and the program can continue
    elif name == name_file[password_file.index(password)] and password == password_file[name_file.index(name)]:
        print(f'Welcome {name}')
        heading(f'- Options')
        start_program = 'yes'
    return start_program


def get_choice(menu_option_number):
    """ This function enable the user choose only 1, 2 or 3 and then store that value
    different menus was created as variable to run different tasks in the programming """
    menu = ''
    menu_initial = "1. Record Attendance \n" \
                   "2. Generate Statistic \n" \
                   "3. Exit \n" \
                   "> "

    menu_attendance_number = "1. Present \n" \
                             "2. Absent \n" \
                             "3. Excused \n" \
                             "> "

    if menu_option_number == 1:
        menu = menu_initial
    elif menu_option_number == 2:
        menu = menu_attendance_number

    while True:
        try:
            number = positive_number(menu)
            if 1 <= number <= 3:
                break
            else:
                print("Values 1, 2 or 3 please...")
        except ValueError:
            print("Values 1, 2 or 3 please...")
    return number


def module_choice(prompt, module_code):
    """ This function enable the user choose between 1 or 2 (because we have only two modules in that case)"""
    while True:
        try:
            number = positive_number(prompt)
            if 1 <= number <= len(module_code):
                break
            else:
                print(f'Values need to be between 1 and {len(module_code)}  please')
        except ValueError:
            print(f'Values need to be between 1 and {len(module_code)}  please')
    return number


def choose_module(option_module):
    """This function receive an input from user and then give a respective module"""
    module = ''
    if option_module == 1:
        module = 'SOFT_6018.txt'
    if option_module == 2:
        module = 'SOFT_6017.txt'
    return module


def read_data_module(name_file):
    """This function take a file (module.txt) and create 2 lists per line, with the module code and module name"""
    module_code_list = []
    module_name_list = []
    connection = open(name_file)
    while True:
        line = connection.readline()
        if line == "":
            break
        line_data = line.split(',')
        module_code_list.append(line_data[0].rstrip())
        module_name_list.append(line_data[1].rstrip())
    return module_code_list, module_name_list


def read_data_attendance(name_file):
    """This function take a file (chosen by user) and create 4 lists per line (name/present/absent/excused)"""
    name_list = []
    present_list = []
    absent_list = []
    excused_list = []
    connection = open(name_file)
    while True:
        line = connection.readline()
        if line == "":
            break
        line_data = line.split(',')
        # name of list . add the data (what index position on the line) . remove space to the right of the string
        name_list.append(line_data[0].rstrip())
        present_list.append(int(line_data[1].rstrip()))
        absent_list.append(int(line_data[2].rstrip()))
        excused_list.append(int(line_data[3].rstrip()))
    return name_list, present_list, absent_list, excused_list


def create_statistic(filename):
    """This function take the 4 lists created from a specific file
    then use some calculations to achieve general statistics"""
    name_list, present_list, absent_list, excused_list = read_data_attendance(filename)
    number_of_students = len(name_list)
    # sum of each attendance of the first student to get the total of classes
    number_class = present_list[0] + absent_list[0] + excused_list[0]
    average_attendance = sum(present_list) / number_of_students
    return number_of_students, number_class, average_attendance


def display_statistic(number_of_students, number_class, average_attendance):
    """This function get the parameters and then print them on the screen
    return information to be stored in a file """
    print(f'Number Students : {number_of_students}')
    print(f'Number of Class: {number_class}')
    print(f'Average attendance {average_attendance:.1f} days')
    statistic_file = (f'Number Students : {number_of_students}\nNumber of Class: {number_class}\n'
                      f'Average attendance {average_attendance:.1f}')
    return statistic_file


def comparation(filename):
    """This function take the 4 lists created from a specific file
    then use if statements to compare the attendance of students
    return information to be stored in a file"""
    name_list, present_list, absent_list, excused_list = read_data_attendance(filename)
    number_class = present_list[0] + absent_list[0] + excused_list[0]
    best_attendant, no_attendant, low_attendant = '', '', ''
    larger = 0
    for check in range(len(name_list)):  # loop and if statement to get more than one option on the list
        if check == 0:
            larger = present_list[check]
        else:
            if present_list[check] > larger:
                larger = present_list[check]
    biggest_attendance = max(present_list)

    print(f'Low attender(s) under 70%:')
    for index in range(len(name_list)):      # loop and if statement to get the name of the low attendant
        if present_list[index] <= number_class * 0.69:
            print(f'\t{name_list[index]}')
            low_attendant = name_list[index]

    print('Non attender(s):')
    for index, value in enumerate(present_list):  # loop and if statement to get the name of the non attendant
        if value == 0:
            print(f'\t{name_list[index]} ')
            no_attendant = name_list[index]

    print('Best attender(s):')
    print(f' \tAttended {biggest_attendance}/ {number_class} days', end=' ')   # end to put the name after the str
    for index, value in enumerate(present_list):  # loop and if statement to get the name of the best attendant
        if value == larger:
            print()
            print(f' \t{name_list[index]}', end='')
            best_attendant = name_list[index]
    print()

    comparation_file = f'Best attender(s): Attended {biggest_attendance}/ {number_class} days {best_attendant}' \
                       f'\nNon attender(s):{no_attendant}\nLow attender(s) under 70%: {low_attendant}'
    return comparation_file


def create_file(filename, module_name, statistic_file, comparation_file):
    """This function create a new file, called with the date + module code
    to store all the statistics created"""
    import datetime
    x = datetime.datetime.now()
    date_name = (x.strftime('%d_%B_%Y_'))  # day_month name_4 digits year
    module_name = module_name.replace(' ', '_')
    new_file = (f"{date_name}{module_name}"+'.txt')
    date_file = date_name.replace('_', ' ')
    name_of_file = open(f'{new_file}', 'w')
    print(f'Statistics for {date_file}', file=name_of_file)
    module_code = filename.replace('.txt', '.')
    print(f'Module code: {module_code}', file=name_of_file)
    print(f'Module name: {module_name}', file=name_of_file)
    print(statistic_file, file=name_of_file)
    print(comparation_file, file=name_of_file)
    name_of_file.close()


def update_attendance_data(name_list, present_list, absent_list, excused_list):
    """This function get all the students by name and index
    and the change the previous attendance value from list and add 1 to it"""
    for index, value in enumerate(name_list):
        print(f'Student #{index + 1}: {value} ')
        attendance_option = get_choice(2)
        if attendance_option == 1:
            present_list[index] = (present_list[index] + 1)
        elif attendance_option == 2:
            absent_list[index] = (absent_list[index] + 1)
        elif attendance_option == 3:
            excused_list[index] = (excused_list[index] + 1)


def store_new_data(select_module, name_list, present_list, absent_list, excused_list):
    """This function will get the attendance to update the file"""
    file_write_new_data = open(select_module, "w")
    for index in range(len(name_list)):
        print(f"{name_list[index]},{present_list[index]},{absent_list[index]},{excused_list[index]}",
              file=file_write_new_data)
    file_write_new_data.close()
    print(f'{select_module} updated with latest attendance records')


def specific_heading(users_choice):
    heading_option = ''
    if users_choice == 1:
        heading_option = '(Attendance)'
    if users_choice == 2:
        heading_option = '(Statistic)'
    heading(f'{heading_option} - Choose a Module')
    module_code, module_name = read_data_module('module.txt')
    for start, item in enumerate(module_name):
        print(f'{start + 1}. {module_code[start]} ')
    option_module = module_choice('> ', module_code)
    chosen_module = module_name[option_module - 1]
    select_module = choose_module(option_module)
    if users_choice == 1:
        heading(f'{heading_option}  {chosen_module}')
    elif users_choice == 2:
        print(f'Module: {chosen_module}')
    return option_module, chosen_module, select_module


def main():
    name, password = login_data()
    filename = 'login_data.txt'  # file created by the programmer
    name_file, password_file = read_data_login(filename)
    run_program = login_validation(name, password, name_file, password_file)  # start the program or fail
    if run_program == 'yes':
        while True:
            users_choice = get_choice(1)  # 1 is related of what kind of menu we need

            if users_choice == 1:
                option_module, chosen_module, select_module = specific_heading(users_choice)
                name_list, present_list, absent_list, excused_list = read_data_attendance(select_module)
                quantity_students = len(name_list)
                print(f'There are {quantity_students} Students enrolled')
                update_attendance_data(name_list, present_list, absent_list, excused_list)
                store_new_data(select_module, name_list, present_list, absent_list, excused_list)

            elif users_choice == 2:
                option_module, chosen_module, select_module = specific_heading(users_choice)
                if option_module == 1 or option_module == 2:
                    number_of_students, number_class, average_attendance = create_statistic(select_module)
                    statistic_file = display_statistic(number_of_students, number_class, average_attendance)
                    comparation_file = comparation(select_module)
                    create_file(select_module, chosen_module, statistic_file, comparation_file)

            elif users_choice == 3:  # Loop for finish the program only if user type 3
                break


main()
